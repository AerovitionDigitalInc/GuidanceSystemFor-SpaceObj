
/*
 * Aerovition Digital Inc.
 * Authror: Shaw Rahman
 * All rights reserved.
 */


package guidanceSystemsPackage;

public enum EdgePropertyTypeValueEnumerator {
	
	//holds enumerated relationship strings..between adjacent nodes or space objects..

}
