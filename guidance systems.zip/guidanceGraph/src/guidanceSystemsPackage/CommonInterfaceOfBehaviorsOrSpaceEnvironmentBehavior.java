/*
 * Aerovition Digital Inc.
 * Authror: Shaw Rahman
 * All rights reserved.
 */

package guidanceSystemsPackage;

public interface CommonInterfaceOfBehaviorsOrSpaceEnvironmentBehavior {
    public  void mision_abort();
	public void mission_init();
	public void disembark();
	}
