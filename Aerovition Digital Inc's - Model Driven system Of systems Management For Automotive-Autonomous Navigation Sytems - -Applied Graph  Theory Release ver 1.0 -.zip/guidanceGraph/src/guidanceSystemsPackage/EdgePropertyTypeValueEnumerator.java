
/*
 * Aerovition Digital Inc.
 * Authror: Shaw Rahman
 * All rights reserved.
 * Copyright @2017;
 * Intellectual property
 */


package guidanceSystemsPackage;

public enum EdgePropertyTypeValueEnumerator {
	
	//holds enumerated relationship strings..between adjacent nodes or space objects..

}
